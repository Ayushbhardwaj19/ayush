package com.simactivation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//the tester class for testing the application


@SpringBootTest
class SimActivationApplicationTests {

	@Test
	void contextLoads() {
	}

}
