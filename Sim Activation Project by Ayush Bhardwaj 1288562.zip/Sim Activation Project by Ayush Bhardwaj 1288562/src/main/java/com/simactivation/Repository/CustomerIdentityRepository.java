package com.simactivation.Repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.simactivation.Entity.CustomerIdentity;

//the repository interface for customer identity table

@Repository("customeridentityrepo")
public interface CustomerIdentityRepository extends JpaRepository<CustomerIdentity,String> {

	@Query("select c from CustomerIdentity c where c.firstName=?1 and c.lastName=?2 and c.emailAddress=?3")        //user defined query for performing the operations of finding data
	public Optional<CustomerIdentity> findByFirstNameLastNameAndEmail(String firstName,String lastName,String email);
	
}
