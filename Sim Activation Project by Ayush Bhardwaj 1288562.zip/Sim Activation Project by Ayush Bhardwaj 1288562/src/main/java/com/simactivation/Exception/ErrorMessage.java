package com.simactivation.Exception;

//an error message class to define the characteristics of the error message that will be displayed upon encountering an exception in the run time


public class ErrorMessage {

	private int statusCode;			//status code of the error
	private String message;			//error message that needs to be displayed
	
	public ErrorMessage(){	
	}
	
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
