package com.simactivation.Exception;

// a developer defined exception class which will be raised whenever sim card validation fails for whatever reason, this exception's body is defined in the global exception handler

public class SimCardNotValidatedException extends Exception {
	
	private static final long serialVersionUID = 1L;
	public SimCardNotValidatedException(String message) {
		super(message);
	}
	
}
