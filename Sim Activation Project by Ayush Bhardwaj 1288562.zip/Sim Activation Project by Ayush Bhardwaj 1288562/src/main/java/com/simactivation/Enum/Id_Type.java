package com.simactivation.Enum;

//an enum to store constants

public enum Id_Type {
	
   AADHAR,PANCARD,PASSPORT,VOTERID,DRIVINGLICENCE
   
}
