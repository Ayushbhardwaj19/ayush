package com.simactivation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

//the spring boot starter class for the application consisting the spring boot run method to initiate the launch

@SpringBootApplication
public class SimActivationApplication {
	public static void main(String[] args) {
		SpringApplication.run(SimActivationApplication.class, args);
	}
	
}
