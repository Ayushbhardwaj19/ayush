package com.simactivation.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.simactivation.DTO.SimDetailsDTO;
import com.simactivation.Entity.SimDetails;
import com.simactivation.Entity.SimOffers;
import com.simactivation.Exception.SimCardNotValidatedException;
import com.simactivation.Repository.SimDetailsRepository;

//the service class for sim details table where the bodies of functions that are bring called by the sim details controller class are defined


@Service("SimdetailsService")
public class SimDetailService implements SimDetailsService{

	private SimDetailsRepository simDetailsRepository;
    @Autowired
	public void setSimDetailsRepository(SimDetailsRepository simDetailsRepository) {
		this.simDetailsRepository = simDetailsRepository;
	}


	@Override
	public void insertRecord(SimDetailsDTO dto) throws Exception {

		//checking for pair validation
		List<SimDetails> detailsList = simDetailsRepository.checkForPair(dto.getSimNumber(),dto.getServiceNumber());
		System.out.println("VALUE"+detailsList);
		 if(!detailsList.isEmpty()) {
			 
			 throw new Exception("CAN'T ADD AS RECORD ALREADY EXISTS");
		 }
		
			 
			 SimDetails simDetails = SimDetailsDTO.convertDTOToEntity(dto);
			 simDetailsRepository.save(simDetails);
		
	}

    @Override
	public List<SimOffers> getOffersByValidation(SimDetailsDTO dto) throws SimCardNotValidatedException {


		Optional<SimDetails> optSimCardDetails = simDetailsRepository.checkForBoth(dto.getSimNumber(), dto.getServiceNumber());
		
		
		if(optSimCardDetails.isEmpty() || !optSimCardDetails.get().getSimStatus()) {
			throw new SimCardNotValidatedException("NOT VALID DETAILS");
		}
	
		List<SimOffers> offers = optSimCardDetails.get().getOffers();
		
	    return offers;
	    
	}

}
