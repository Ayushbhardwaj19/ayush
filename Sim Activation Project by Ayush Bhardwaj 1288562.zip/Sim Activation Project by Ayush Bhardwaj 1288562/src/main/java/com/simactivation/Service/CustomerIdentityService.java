package com.simactivation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.simactivation.DTO.CustomerIdentityDTO;
import com.simactivation.Entity.CustomerIdentity;
import com.simactivation.Repository.CustomerIdentityRepository;

//the service class for customer identity table where the bodies of functions that are bring called by the customer identity controller class are defined


@Service("customerIdentityService")
public class CustomerIdentityService {
     
	private CustomerIdentityRepository identityRepo;
	
	@Autowired
	public void setIdentityRepo(CustomerIdentityRepository identityRepo) {
		this.identityRepo = identityRepo;
	}
	
	public void add(CustomerIdentityDTO dto) throws Exception{
	
		System.out.println(dto.getUniqueIdNumber()+"   "+identityRepo.existsById(dto.getUniqueIdNumber()));
		if(identityRepo.existsById(dto.getUniqueIdNumber())) {
			throw new Exception("Customer is already present");
		}
		CustomerIdentity identityEntity = CustomerIdentityDTO.convertDTOToEntity(dto);
		identityRepo.save(identityEntity);
		
	}
}
