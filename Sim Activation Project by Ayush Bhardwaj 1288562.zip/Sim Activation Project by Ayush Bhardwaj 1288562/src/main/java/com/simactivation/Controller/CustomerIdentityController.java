package com.simactivation.Controller;
import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.simactivation.DTO.CustomerIdentityDTO;
import com.simactivation.Service.CustomerIdentityService;


//the controller class for the customer identity in the database.

@RestController
@RequestMapping("/customeridentity")				//request mapping annotation marked with the uri needed
public class CustomerIdentityController {
	
	
	@Autowired
	private CustomerIdentityService identityService;

	@PostMapping("/add")								//post mapping operation defined with required uri to perform the operation of adding the customer
	public ResponseEntity<Object> addCustomer(@RequestBody @Valid CustomerIdentityDTO dto) throws Exception{
		identityService.add(dto);
		HashMap<String,Object> hm= new HashMap<>();
		hm.put("success","true");
		hm.put("data",null);
		return ResponseEntity.ok(hm);	
	}

}
