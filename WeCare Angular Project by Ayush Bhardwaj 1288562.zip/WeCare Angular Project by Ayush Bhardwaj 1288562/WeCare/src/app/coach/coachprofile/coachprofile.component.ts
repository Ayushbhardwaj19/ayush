import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coachprofile',
  templateUrl: './coachprofile.component.html',
  styleUrls: ['./coachprofile.component.css']
})
export class CoachprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
